#include <iostream>
#include <iostream>
using namespace std;

int main() {
    int x;
    cin >> x;

    if (x > 0) {
        cout << 1 << endl;
    } else if (x < 0) {
        cout << -1 << endl;
    } else {
        cout << 0 << endl;
    }

    return 0;
}


