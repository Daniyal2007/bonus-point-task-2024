#include <iostream>
using namespace std;
int main (){
	int a,b,c;
	cin>>a>>b>>c;
	int m=max(a, b);
	int n=max(m,c);
	cout<<n;
} 
