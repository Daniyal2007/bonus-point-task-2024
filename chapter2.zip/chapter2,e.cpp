#include <iostream>
using namespace std;
int main (){
	int a1,a2;
	cin>>a1>>a2;
	if(a1==a2)
	cout<<"0";
	else if(a1>a2)
	cout<<"1";
	else
	cout<<"2";
}   
