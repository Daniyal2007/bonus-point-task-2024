#include <bits/stdc++.h>
using namespace std;
int main(){
    int b;
	cin>>b;
	int a=1;
	while (a*a<=b){
	cout<<a*a<<endl;
	a++;	
	}    
}

