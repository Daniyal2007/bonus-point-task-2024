#include <iostream>
#include <cmath>
using namespace std;
int main (){
	int a,ans;
	cin>>a;
	for(int i=0;i<=a;i++){
	ans=pow(2,a);
}
		cout<<ans;
	}
