#include <bits/stdc++.h>
using namespace std;
int main (){
	int n;
	int m;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>m;
		if(m==0){
			cout<<"YES";
			return 0;
		}
			
	}cout<<"NO";
}
