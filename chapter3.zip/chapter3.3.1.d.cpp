#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n,ans=0;
	
	while(true)
	{
		
		cin>>n;
	 	
	   		if(n==0)
				break;
		 
		 	if(n%2==0)
		 		ans++;
		 	
}
	
	cout<<ans;
	
}
