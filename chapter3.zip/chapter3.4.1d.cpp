#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n,ans=0,a=1,mn=1000000,mx=0;
	cin>>n;
	while(n>=a){
		ans=(n/a)%2;
		a*=2;
		if(ans%2==0)
			cout<<"0";
		else
			cout<<"1";
	}
}
