#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n,ans=1;
	
	while(true)
	{
		
		cin>>n;
	 	
	   		if(n==0)
				break;
		 
		 	if(ans<n)
		 		ans=n;
		 	
}
	
	cout<<ans;
	
}
