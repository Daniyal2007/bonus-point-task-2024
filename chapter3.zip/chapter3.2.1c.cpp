#include <iostream>
using namespace std;
int main (){
	int b,i=1;
	cin>>b;
	while (i<=b){
		
		cout<< i <<" ";
		i*=2;
	}
}
