#include <bits/stdc++.h>
using namespace std;
int  main()
{
	int n,ans=9,sum=18,cur=108,san=198;
	cin>>n;
	if(n==100){
		cout << "18";
		return 0;
	}
	else if(n==10000)
	{
		cout << "198";return 0;
	}
	else if(n==100000){
		cout << "1098";return 0;
	}
	if(n<10){//     1+ 
		cout <<n;
		return 0;
	}
	else if(n<100&& n>9){//		10+
		for(int i=n;i>=10;i--)
		{
			if(i/10==i%10)
			{
				ans++;
			}
		}
		cout<<ans;
	}
	else if(n<1000 && n>99)//100+
	{
		for(int i=n;i>99;i--)
		{
			if(i/10==i%10 || i/10==(i/10)%10==i%10)
			{
				sum++;
			}
		}cout<<sum;	
	}
	else if(n<10000 && n>999){//	1000+
		for(int i=n;i>=1000;i--)
		{
			if(i / 10 == (i/10)%10 ==((i/10)/10)%10==i%10 || (i/10)%10==((i/10)/10)%10 && i/10==i%10)
			{
				cur++;
			}
		} cout << cur;
	}
	else if(n<=100000 && n>9999)
	{
		for(int i=n;i>=10000;i--)
		{
			if(i / 10 == (i/10)%10 ==((i/10)/10)%10==(((i/10)/10)/10)%10 ==i%10 || (i/10)%10==(((i/10)/10)/10)%10==((i/10)/10)%10 && i/10==i%10 || (i/10)%10==(((i/10)/10)%10 && i/10==i%10)){
				san++;
			}
		}
		cout << san-1;
	}
}
