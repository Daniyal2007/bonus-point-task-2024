#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n,ans=0,a=1;
	cin>>n;
	while(n>=a){
		ans+=(n/a)%10;
		a*=10;
	}
	cout<<ans;
}
