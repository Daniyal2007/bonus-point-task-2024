#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n,ans=0,a=1,cur=0;
	cin>>n;
	while(n>=a){
		ans=(n/a)%10;
		a*=10;
		if(ans==0){
			cur++;
		}
	}
	cout<<cur;
}
