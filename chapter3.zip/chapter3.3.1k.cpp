#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n=1, prev=-1, res=0, cur=1;
	
	while(true)
	{
		cin>>n;
		
		if(n==0)
			break;
		
		if(n==prev)
			cur++;
		else
		{
			res=max(res,cur);
			cur=1;
		}
		prev=n;
	}
	res = max(res,cur);
	cout<<res;
	
}
