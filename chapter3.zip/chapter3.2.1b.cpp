#include <iostream> 
using namespace std;
int main (){
	int i=2,b;
	cin>>b;
	while (i<=b) {
		
	    
	    if(b%i==0){
	    	cout<<i;
	return 0;
		}
		i++;
	}
}
