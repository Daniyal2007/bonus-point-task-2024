#include <iostream>
using namespace std;

int main() {
    int n, m; 
    cin >> n >> m;
	int a;
	a = max(n, m);
	cout<<a;

    return 0;
}

