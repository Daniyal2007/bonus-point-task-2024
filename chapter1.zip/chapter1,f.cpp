#include <iostream>
using namespace std;

int main() {
    long long n; 
	    cin >> n;

     int lastDigit = n % 10;

      cout << lastDigit << endl;

    return 0;
}
