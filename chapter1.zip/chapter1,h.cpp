#include <iostream>
using namespace std;

int main() {
    long long n; 
    cin >> n;

        int tens = (n / 10) % 10;

     cout << tens << endl;

    return 0;
}

