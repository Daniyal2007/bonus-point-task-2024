#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int n,m;
	cin>>n>>m;
	cout<<sqrt(n*n + m*m);
}
