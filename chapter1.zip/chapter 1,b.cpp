#include <iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
	cout<<"The next number for the number "<<n<<" is "<<n+1<<"."<<endl<<"The previous number for the number "<<n<<" is "<<n-1<<".";
}
