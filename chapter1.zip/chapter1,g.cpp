#include <iostream>
using namespace std;

int main() {
    int n; 
    cin >> n;

        int tens = n / 10;

     cout << tens << endl;

    return 0;
}

